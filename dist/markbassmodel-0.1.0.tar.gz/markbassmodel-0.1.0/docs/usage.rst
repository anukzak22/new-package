=====
Usage
=====

To use markbassmodel in a project::

    import markbassmodel
