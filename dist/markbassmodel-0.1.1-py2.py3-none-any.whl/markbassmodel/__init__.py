"""Top-level package for markbassmodel."""

__author__ = """Anahit Zakaryan"""
__email__ = 'anukzak@gmail.com'
__version__ = '0.1.0'
